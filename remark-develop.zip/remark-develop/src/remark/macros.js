var macros = module.exports = {};

macros.hello = function () {
  return 'hello!';
};
